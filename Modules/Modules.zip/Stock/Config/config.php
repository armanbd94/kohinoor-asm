<?php

return [
    'name' => 'Stock'
];

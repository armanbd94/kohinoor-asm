<?php

return [
    'name' => 'StockReturn'
];

<?php

return [
    'name' => 'Bank'
];
